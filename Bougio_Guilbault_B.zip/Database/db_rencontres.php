<?php
require_once 'database.php';

function getAllRencontres() {
    global $pdo;
    $stmt = $pdo->prepare("
        SELECT * FROM rencontre
        ORDER BY date_rencontre DESC
    ");
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Fonction pour récupérer tous les rencontres à venir
function getRencontresAVenir() {
    global $pdo;
    $stmt = $pdo->prepare("
        SELECT * FROM rencontre 
        WHERE date_rencontre >= NOW()
        ORDER BY date_rencontre ASC
    ");
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Récupérer les rencontres passées
function getRencontresPassees() {
    global $pdo;
    $stmt = $pdo->prepare("
        SELECT * FROM rencontre 
        WHERE date_rencontre < NOW()
        ORDER BY date_rencontre DESC
    ");
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Fonction pour ajouter un rencontre avec les champs supplémentaires
function addRencontre($date, $adversaire, $lieu) {
    global $pdo;
    $stmt = $pdo->prepare("INSERT INTO rencontre (date_rencontre, lieu, adversaire, resultat) VALUES (?, ?, ?, ?)");
    $stmt->execute([$date, $lieu, $adversaire, '0-0']);
}

// Mettre à jour les informations d'une rencontre
function updateRencontre($id_rencontre, $date_rencontre, $adversaire, $lieu) {
    global $pdo;
    $stmt = $pdo->prepare("
        UPDATE rencontre 
        SET date_rencontre = ?, adversaire = ?, lieu = ? 
        WHERE id_rencontre = ?
    ");
    $stmt->execute([$date_rencontre, $adversaire, $lieu, $id_rencontre]);
}

function updateResultatRencontre($id_rencontre, $resultat) {
    global $pdo;
    $stmt = $pdo->prepare("
        UPDATE rencontre 
        SET resultat = ? 
        WHERE id_rencontre = ?
    ");
    $stmt->execute([$resultat, $id_rencontre]);
}

function deleteRencontre($id_rencontre) {
    global $pdo;
    $stmt = $pdo->prepare("DELETE FROM rencontre WHERE id_rencontre = ?");
    $stmt->execute([$id_rencontre]);
}

// Récupérer une rencontre spécifique
function getRencontreById($id_rencontre) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM rencontre WHERE id_rencontre = ?");
    $stmt->execute([$id_rencontre]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

// Récupérer les joueurs associés à une rencontre
function getJoueursByRencontre($id_rencontre) {
    global $pdo;
    $stmt = $pdo->prepare("
        SELECT p.*, j.nom, j.prenom 
        FROM participer p
        JOIN joueur j ON p.id_joueur = j.id_joueur
        WHERE p.id_rencontre = ?
    ");
    $stmt->execute([$id_rencontre]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Ajouter un joueur à une rencontre avec un poste et un statut
function addJoueurToRencontre($id_rencontre, $id_joueur, $poste, $titulaire) {
    global $pdo;
    $stmt = $pdo->prepare("INSERT INTO participer (id_rencontre, id_joueur, poste, titulaire) VALUES (?, ?, ?, ?)");
    $stmt->execute([$id_rencontre, $id_joueur, $poste, $titulaire]);
}

// Mettre à jour le poste et le statut d'un joueur dans une rencontre
function updateJoueurInRencontre($id_rencontre, $id_joueur, $poste, $titulaire) {
    global $pdo;
    $stmt = $pdo->prepare("
        UPDATE participer 
        SET poste = ?, titulaire = ? 
        WHERE id_rencontre = ? AND id_joueur = ?
    ");
    $stmt->execute([$poste, $titulaire, $id_rencontre, $id_joueur]);
}

function updateJoueurNoteInRencontre($id_rencontre, $id_joueur, $note) {
    global $pdo;
    $stmt = $pdo->prepare("
        UPDATE participer 
        SET note = ?
        WHERE id_rencontre = ? AND id_joueur = ?
    ");
    $stmt->execute([$note, $id_rencontre, $id_joueur]);
}

function deleteJoueurInRencontre($id_joueur, $id_rencontre){
    global $pdo;
    $stmt = $pdo->prepare("DELETE FROM participer WHERE id_joueur = ? AND id_rencontre = ?");
    $stmt->execute([$id_joueur, $id_rencontre]);
}
?>