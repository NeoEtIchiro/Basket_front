<?php
// joueurs_model.php
require_once 'database.php';
// db_joueurs.php

// Fonction pour récupérer tous les joueurs
function getAllJoueurs() {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM joueur");
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Fonction pour ajouter un joueur avec les champs supplémentaires
function addJoueur($nom, $prenom, $numero_licence, $date_naissance, $taille, $poids, $commentaire, $statut) {
    global $pdo;
    $stmt = $pdo->prepare("INSERT INTO joueur (nom, prenom, licence, dateNaissance, taille, poids, commentaire, statut) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$nom, $prenom, $numero_licence, $date_naissance, $taille, $poids, $commentaire, $statut]);
}

// Fonction pour mettre à jour le commentaire et le statut d'un joueur
function updateJoueur($id, $nom, $prenom, $numero_licence, $date_naissance, $taille, $poids, $commentaire, $statut) {
    global $pdo;
    $stmt = $pdo->prepare("UPDATE joueur 
                                  SET nom = ?, prenom = ?, licence = ?, dateNaissance = ?, taille = ?, poids = ?, commentaire = ?, statut = ?
                                  WHERE id_joueur = ?");
    $stmt->execute([$nom, $prenom, $numero_licence, $date_naissance, $taille, $poids, $commentaire, $statut, $id]);
}

function deleteJoueur($id_joueur) {
    global $pdo;
    $stmt = $pdo->prepare("DELETE FROM participer WHERE id_joueur = ?");
    $stmt->execute([$id_joueur]);

    $stmt = $pdo->prepare("DELETE FROM joueur WHERE id_joueur = ?");
    $stmt->execute([$id_joueur]);
}

function hasParticipatedInRencontres($id_joueur) {
    global $pdo; // Assurez-vous que l'objet $db est accessible
    $query = "SELECT COUNT(*) as count FROM participer WHERE id_joueur = :id_joueur";
    $stmt = $pdo->prepare($query);
    $stmt->execute(['id_joueur' => $id_joueur]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result['count'] > 0; // Retourne true si le joueur a participé à au moins une rencontre
}

?>